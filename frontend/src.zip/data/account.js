const users = [
  {
    //id: '5e86809283e28b96d2d38537',
    // email: 'info@codedthemes.com',
    // password: '123456',
    //name: 'JWT User'
    id: '',
    email: '',
    password: '',
    name: ''
  }
];

export default users;
